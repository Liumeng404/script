declare module 'astro:content' {
	interface Render {
		'.mdx': Promise<{
			Content: import('astro').MarkdownInstance<{}>['Content'];
			headings: import('astro').MarkdownHeading[];
			remarkPluginFrontmatter: Record<string, any>;
		}>;
	}
}

declare module 'astro:content' {
	interface Render {
		'.md': Promise<{
			Content: import('astro').MarkdownInstance<{}>['Content'];
			headings: import('astro').MarkdownHeading[];
			remarkPluginFrontmatter: Record<string, any>;
		}>;
	}
}

declare module 'astro:content' {
	type Flatten<T> = T extends { [K: string]: infer U } ? U : never;

	export type CollectionKey = keyof AnyEntryMap;
	export type CollectionEntry<C extends CollectionKey> = Flatten<AnyEntryMap[C]>;

	export type ContentCollectionKey = keyof ContentEntryMap;
	export type DataCollectionKey = keyof DataEntryMap;

	type AllValuesOf<T> = T extends any ? T[keyof T] : never;
	type ValidContentEntrySlug<C extends keyof ContentEntryMap> = AllValuesOf<
		ContentEntryMap[C]
	>['slug'];

	export function getEntryBySlug<
		C extends keyof ContentEntryMap,
		E extends ValidContentEntrySlug<C> | (string & {}),
	>(
		collection: C,
		// Note that this has to accept a regular string too, for SSR
		entrySlug: E
	): E extends ValidContentEntrySlug<C>
		? Promise<CollectionEntry<C>>
		: Promise<CollectionEntry<C> | undefined>;

	export function getDataEntryById<C extends keyof DataEntryMap, E extends keyof DataEntryMap[C]>(
		collection: C,
		entryId: E
	): Promise<CollectionEntry<C>>;

	export function getCollection<C extends keyof AnyEntryMap, E extends CollectionEntry<C>>(
		collection: C,
		filter?: (entry: CollectionEntry<C>) => entry is E
	): Promise<E[]>;
	export function getCollection<C extends keyof AnyEntryMap>(
		collection: C,
		filter?: (entry: CollectionEntry<C>) => unknown
	): Promise<CollectionEntry<C>[]>;

	export function getEntry<
		C extends keyof ContentEntryMap,
		E extends ValidContentEntrySlug<C> | (string & {}),
	>(entry: {
		collection: C;
		slug: E;
	}): E extends ValidContentEntrySlug<C>
		? Promise<CollectionEntry<C>>
		: Promise<CollectionEntry<C> | undefined>;
	export function getEntry<
		C extends keyof DataEntryMap,
		E extends keyof DataEntryMap[C] | (string & {}),
	>(entry: {
		collection: C;
		id: E;
	}): E extends keyof DataEntryMap[C]
		? Promise<DataEntryMap[C][E]>
		: Promise<CollectionEntry<C> | undefined>;
	export function getEntry<
		C extends keyof ContentEntryMap,
		E extends ValidContentEntrySlug<C> | (string & {}),
	>(
		collection: C,
		slug: E
	): E extends ValidContentEntrySlug<C>
		? Promise<CollectionEntry<C>>
		: Promise<CollectionEntry<C> | undefined>;
	export function getEntry<
		C extends keyof DataEntryMap,
		E extends keyof DataEntryMap[C] | (string & {}),
	>(
		collection: C,
		id: E
	): E extends keyof DataEntryMap[C]
		? Promise<DataEntryMap[C][E]>
		: Promise<CollectionEntry<C> | undefined>;

	/** Resolve an array of entry references from the same collection */
	export function getEntries<C extends keyof ContentEntryMap>(
		entries: {
			collection: C;
			slug: ValidContentEntrySlug<C>;
		}[]
	): Promise<CollectionEntry<C>[]>;
	export function getEntries<C extends keyof DataEntryMap>(
		entries: {
			collection: C;
			id: keyof DataEntryMap[C];
		}[]
	): Promise<CollectionEntry<C>[]>;

	export function reference<C extends keyof AnyEntryMap>(
		collection: C
	): import('astro/zod').ZodEffects<
		import('astro/zod').ZodString,
		C extends keyof ContentEntryMap
			? {
					collection: C;
					slug: ValidContentEntrySlug<C>;
				}
			: {
					collection: C;
					id: keyof DataEntryMap[C];
				}
	>;
	// Allow generic `string` to avoid excessive type errors in the config
	// if `dev` is not running to update as you edit.
	// Invalid collection names will be caught at build time.
	export function reference<C extends string>(
		collection: C
	): import('astro/zod').ZodEffects<import('astro/zod').ZodString, never>;

	type ReturnTypeOrOriginal<T> = T extends (...args: any[]) => infer R ? R : T;
	type InferEntrySchema<C extends keyof AnyEntryMap> = import('astro/zod').infer<
		ReturnTypeOrOriginal<Required<ContentConfig['collections'][C]>['schema']>
	>;

	type ContentEntryMap = {
		"posts": {
"2016-12-14-接下来。。。.md": {
	id: "2016-12-14-接下来。。。.md";
  slug: "2016-12-14-接下来";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2016-12-16-自己建站Wordpress小流程.md": {
	id: "2016-12-16-自己建站Wordpress小流程.md";
  slug: "2016-12-16-自己建站wordpress小流程";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2016-12-24-2016年10月10日工作总结.md": {
	id: "2016-12-24-2016年10月10日工作总结.md";
  slug: "2016-12-24-2016年10月10日工作总结";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2016-12-24-2016年自我总结.md": {
	id: "2016-12-24-2016年自我总结.md";
  slug: "2016-12-24-2016年自我总结";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2016-12-25-《做事的常识》.md": {
	id: "2016-12-25-《做事的常识》.md";
  slug: "2016-12-25-做事的常识";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-01-02-2017年计划.md": {
	id: "2017-01-02-2017年计划.md";
  slug: "2017-01-02-2017年计划";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-01-02-元旦聚会.md": {
	id: "2017-01-02-元旦聚会.md";
  slug: "2017-01-02-元旦聚会";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-01-10-时间管理.md": {
	id: "2017-01-10-时间管理.md";
  slug: "2017-01-10-时间管理";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-01-14-最强记录片，没有之一：OJ辛普森：美国制造.md": {
	id: "2017-01-14-最强记录片，没有之一：OJ辛普森：美国制造.md";
  slug: "2017-01-14-最强记录片没有之一oj辛普森美国制造";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-02-11-百度前端任务4.md": {
	id: "2017-02-11-百度前端任务4.md";
  slug: "2017-02-11-百度前端任务4";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-02-25-故乡情.md": {
	id: "2017-02-25-故乡情.md";
  slug: "2017-02-25-故乡情";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-02-25-故乡情，我与二叔.md": {
	id: "2017-02-25-故乡情，我与二叔.md";
  slug: "2017-02-25-故乡情我与二叔";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-03-12-老巴里教你 1 ON 1，open attack.md": {
	id: "2017-03-12-老巴里教你 1 ON 1，open attack.md";
  slug: "2017-03-12-老巴里教你-1-on-1open-attack";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-03-19-变动突如其来，又迷茫了.md": {
	id: "2017-03-19-变动突如其来，又迷茫了.md";
  slug: "2017-03-19-变动突如其来又迷茫了";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-05-06-再！爬起来.md": {
	id: "2017-05-06-再！爬起来.md";
  slug: "2017-05-06-再爬起来";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-06-14-卿今者才略，非复吴下阿蒙！.md": {
	id: "2017-06-14-卿今者才略，非复吴下阿蒙！.md";
  slug: "2017-06-14-卿今者才略非复吴下阿蒙";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-07-16-Restrat.md": {
	id: "2017-07-16-Restrat.md";
  slug: "2017-07-16-restrat";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-07-24-餐巾纸的背面.md": {
	id: "2017-07-24-餐巾纸的背面.md";
  slug: "2017-07-24-餐巾纸的背面";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-08-01-质量最多五五开的《很毒很毒的病毒营销》.md": {
	id: "2017-08-01-质量最多五五开的《很毒很毒的病毒营销》.md";
  slug: "2017-08-01-质量最多五五开的很毒很毒的病毒营销";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-08-07-我要给的屁股投个保.md": {
	id: "2017-08-07-我要给的屁股投个保.md";
  slug: "2017-08-07-我要给的屁股投个保";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-08-13-五星《疯传》.md": {
	id: "2017-08-13-五星《疯传》.md";
  slug: "2017-08-13-五星疯传";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-08-13-又起了波澜.md": {
	id: "2017-08-13-又起了波澜.md";
  slug: "2017-08-13-又起了波澜";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-08-24-心里总是有两个小人在打架.md": {
	id: "2017-08-24-心里总是有两个小人在打架.md";
  slug: "2017-08-24-心里总是有两个小人在打架";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-09-10-还是一样的懒惰.md": {
	id: "2017-09-10-还是一样的懒惰.md";
  slug: "2017-09-10-还是一样的懒惰";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-10-30-时光飞逝，最近很丧.md": {
	id: "2017-10-30-时光飞逝，最近很丧.md";
  slug: "2017-10-30-时光飞逝最近很丧";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-11-07-人生难吗？难.md": {
	id: "2017-11-07-人生难吗？难.md";
  slug: "2017-11-07-人生难吗难";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-11-16-有了些改观.md": {
	id: "2017-11-16-有了些改观.md";
  slug: "2017-11-16-有了些改观";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-11-18-一年有感.md": {
	id: "2017-11-18-一年有感.md";
  slug: "2017-11-18-一年有感";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-11-27-想走，到底该怎么办？.md": {
	id: "2017-11-27-想走，到底该怎么办？.md";
  slug: "2017-11-27-想走到底该怎么办";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-12-11-我要去的地方.md": {
	id: "2017-12-11-我要去的地方.md";
  slug: "2017-12-11-我要去的地方";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2017-12-23-2017年年终总结.md": {
	id: "2017-12-23-2017年年终总结.md";
  slug: "2017-12-23-2017年年终总结";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2018-01-18-18年的第一篇吧.md": {
	id: "2018-01-18-18年的第一篇吧.md";
  slug: "2018-01-18-18年的第一篇吧";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2018-02-11-一杯敬远方，一杯敬故乡.md": {
	id: "2018-02-11-一杯敬远方，一杯敬故乡.md";
  slug: "2018-02-11-一杯敬远方一杯敬故乡";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2018-03-10-最后一搏吧.md": {
	id: "2018-03-10-最后一搏吧.md";
  slug: "2018-03-10-最后一搏吧";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2018-03-31-到深圳，新的开始.md": {
	id: "2018-03-31-到深圳，新的开始.md";
  slug: "2018-03-31-到深圳新的开始";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2018-05-01-来深圳的第一个五一.md": {
	id: "2018-05-01-来深圳的第一个五一.md";
  slug: "2018-05-01-来深圳的第一个五一";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2018-06-02-忙忙忙.md": {
	id: "2018-06-02-忙忙忙.md";
  slug: "2018-06-02-忙忙忙";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2018-06-24-老伙计来了，继续战斗下去.md": {
	id: "2018-06-24-老伙计来了，继续战斗下去.md";
  slug: "2018-06-24-老伙计来了继续战斗下去";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2018-07-12-记一次失败的汇报总结的问题.md": {
	id: "2018-07-12-记一次失败的汇报总结的问题.md";
  slug: "2018-07-12-记一次失败的汇报总结的问题";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2018-07-30-早点睡，别忘了来这儿的目的.md": {
	id: "2018-07-30-早点睡，别忘了来这儿的目的.md";
  slug: "2018-07-30-早点睡别忘了来这儿的目的";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2018-08-25-为梦想而活.md": {
	id: "2018-08-25-为梦想而活.md";
  slug: "2018-08-25-为梦想而活";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2018-10-09-国庆回了家，在深圳住的地方也换了.md": {
	id: "2018-10-09-国庆回了家，在深圳住的地方也换了.md";
  slug: "2018-10-09-国庆回了家在深圳住的地方也换了";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2019-01-20-转【内部信】关于项目深度执行的思考.md": {
	id: "2019-01-20-转【内部信】关于项目深度执行的思考.md";
  slug: "2019-01-20-转内部信关于项目深度执行的思考";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2019-01-20-这个周末。。。就是折腾！.md": {
	id: "2019-01-20-这个周末。。。就是折腾！.md";
  slug: "2019-01-20-这个周末就是折腾";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2019-01-27-为了一个自己的需求死磕python.md": {
	id: "2019-01-27-为了一个自己的需求死磕python.md";
  slug: "2019-01-27-为了一个自己的需求死磕python";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2019-02-11-春节回来小感.md": {
	id: "2019-02-11-春节回来小感.md";
  slug: "2019-02-11-春节回来小感";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2019-03-11-来深圳一年了！.md": {
	id: "2019-03-11-来深圳一年了！.md";
  slug: "2019-03-11-来深圳一年了";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2019-05-05-困恼的工作与生活.md": {
	id: "2019-05-05-困恼的工作与生活.md";
  slug: "2019-05-05-困恼的工作与生活";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2019-05-17-工作经历中最困难的一周.md": {
	id: "2019-05-17-工作经历中最困难的一周.md";
  slug: "2019-05-17-工作经历中最困难的一周";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2019-07-07-深圳第三次搬家，IP解禁了.md": {
	id: "2019-07-07-深圳第三次搬家，IP解禁了.md";
  slug: "2019-07-07-深圳第三次搬家ip解禁了";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2019-08-11-这是什么JB破空间.md": {
	id: "2019-08-11-这是什么JB破空间.md";
  slug: "2019-08-11-这是什么jb破空间";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2019-09-30-明儿就国庆，我该怎么过呢？.md": {
	id: "2019-09-30-明儿就国庆，我该怎么过呢？.md";
  slug: "2019-09-30-明儿就国庆我该怎么过呢";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2019-11-13-最近动力不大啊.md": {
	id: "2019-11-13-最近动力不大啊.md";
  slug: "2019-11-13-最近动力不大啊";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2019-12-08-又搬家了，生活成本有高了呀.md": {
	id: "2019-12-08-又搬家了，生活成本有高了呀.md";
  slug: "2019-12-08-又搬家了生活成本有高了呀";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2020-03-06-讲讲为什么三个月没更新了.md": {
	id: "2020-03-06-讲讲为什么三个月没更新了.md";
  slug: "2020-03-06-讲讲为什么三个月没更新了";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2020-05-06-4月的记录.md": {
	id: "2020-05-06-4月的记录.md";
  slug: "2020-05-06-4月的记录";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2020-05-06-无社交？这才是我惶恐的.md": {
	id: "2020-05-06-无社交？这才是我惶恐的.md";
  slug: "2020-05-06-无社交这才是我惶恐的";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2020-05-07-我呢，我什么时候会走呢？.md": {
	id: "2020-05-07-我呢，我什么时候会走呢？.md";
  slug: "2020-05-07-我呢我什么时候会走呢";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2020-05-14-你所认为的别人对你的看法，其实是你自己对你自己看法.md": {
	id: "2020-05-14-你所认为的别人对你的看法，其实是你自己对你自己看法.md";
  slug: "2020-05-14-你所认为的别人对你的看法其实是你自己对你自己看法";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2020-06-12-随处记录.md": {
	id: "2020-06-12-随处记录.md";
  slug: "2020-06-12-随处记录";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2020-07-13-我特么裂开了.md": {
	id: "2020-07-13-我特么裂开了.md";
  slug: "2020-07-13-我特么裂开了";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2020-08-16-我这三年经历的事儿，只能说给自己听.md": {
	id: "2020-08-16-我这三年经历的事儿，只能说给自己听.md";
  slug: "2020-08-16-我这三年经历的事儿只能说给自己听";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2020-10-15-2020年9月到10月的记录.md": {
	id: "2020-10-15-2020年9月到10月的记录.md";
  slug: "2020-10-15-2020年9月到10月的记录";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2020-11-30-Life Is Fucking Movie.md": {
	id: "2020-11-30-Life Is Fucking Movie.md";
  slug: "2020-11-30-life-is-fucking-movie";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2020-12-25-父母的一句“你都混了几年了”，我眼泪瞬间就憋不住了.md": {
	id: "2020-12-25-父母的一句“你都混了几年了”，我眼泪瞬间就憋不住了.md";
  slug: "2020-12-25-父母的一句你都混了几年了我眼泪瞬间就憋不住了";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2021-01-13-网站搬家最后一篇博.md": {
	id: "2021-01-13-网站搬家最后一篇博.md";
  slug: "2021-01-13-网站搬家最后一篇博";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2021-05-13-2021年2月-5月记录.md": {
	id: "2021-05-13-2021年2月-5月记录.md";
  slug: "2021-05-13-2021年2月-5月记录";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2021-06-17-新的地方.md": {
	id: "2021-06-17-新的地方.md";
  slug: "2021-06-17-新的地方";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2021-10-14-生活上不得劲儿，工作上也不得劲儿.md": {
	id: "2021-10-14-生活上不得劲儿，工作上也不得劲儿.md";
  slug: "2021-10-14-生活上不得劲儿工作上也不得劲儿";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2021-12-02-这种感觉特别美好，我很怀恋.md": {
	id: "2021-12-02-这种感觉特别美好，我很怀恋.md";
  slug: "2021-12-02-这种感觉特别美好我很怀恋";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2022-03-14-未命名文档.md": {
	id: "2022-03-14-未命名文档.md";
  slug: "2022-03-14-未命名文档";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
"2022-06-02-域名月底要到期了.md": {
	id: "2022-06-02-域名月底要到期了.md";
  slug: "2022-06-02-域名月底要到期了";
  body: string;
  collection: "posts";
  data: InferEntrySchema<"posts">
} & { render(): Render[".md"] };
};

	};

	type DataEntryMap = {
		
	};

	type AnyEntryMap = ContentEntryMap & DataEntryMap;

	export type ContentConfig = typeof import("./../src/content/config.js");
}
